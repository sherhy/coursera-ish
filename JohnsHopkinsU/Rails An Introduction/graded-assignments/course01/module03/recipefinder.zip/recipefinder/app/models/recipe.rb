# ENV['FOOD2FORK_KEY'] = "7647ea312f22fff136305a5ea2dc126d"
# ENV['FOOD2FORK_SERVER_AND_PORT'] = 'food2fork.com'
class Recipe

  include HTTParty

  base_uri "http://#{ENV['FOOD2FORK_SERVER_AND_PORT']}/api"
  default_params key: ENV['FOOD2FORK_KEY']
  format :json

  def self.for (keyword)
    get("/search", query: {q: keyword})["recipes"]
  end
end

